import data_fixtures
import subprocess
import testdata
import os

date_time_string = data_fixtures.create_unique_date_and_time_string()
image_name = "img" + date_time_string
container_name = "contr" + date_time_string
file_dir = str(os.getcwd()) + "/docker"

subprocess.call(['bash ' + testdata.DIR_NAME + '/create_docker.sh ' + image_name + " " + file_dir + " " + container_name], shell=True)
subprocess.call(['bash ' + testdata.DIR_NAME + '/create_container_json.sh ' + container_name], shell=True)

