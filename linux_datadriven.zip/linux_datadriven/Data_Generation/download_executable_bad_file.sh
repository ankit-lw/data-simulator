#! /bin/bash

if [ $# -eq 2 ]; then
    links=$1
    FILE_DIR=$2

    if [ ! -d "$FILE_DIR" ]; then
        mkdir -p $FILE_DIR
        cd $FILE_DIR && { curl -O $links ; chmod -R 777 * ; }
        if [ $? -eq 0 ]; then
            echo "Bad File Downloaded Successfully From - $links"
            exit 0
        else
            echo "Bad File Cannot Be Downloaded From - $links"
            exit 1
        fi
    fi
else
        echo  "This program needs 2 arguments you have given $#"
        exit 1
fi

