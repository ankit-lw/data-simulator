import urllib2
import socket
import os
from datetime import datetime, timedelta
import time
import random
from datetime import datetime
#import gspread
#from oauth2client.service_account import ServiceAccountCredentials
import testdata
from subprocess import check_output
import requests
import json
import pytz as pytz
import subprocess


def get_public_ip():
    try:
        return str(urllib2.urlopen('https://enabledns.com/ip').read())
    except:
        return None


def get_hostname():
    try:
        return str(socket.gethostname())
    except:
        return None


def get_private_ip():
    try:
        return check_output(['hostname', '--all-ip-address']).split(" ")[0]
    except:
        return None


def create_unique_username():
    try:
        current_time = datetime.now()
        return "ankit_user" + current_time.strftime("%d%m%Y%H%M%S")
    except:
        return None

def create_unique_date_and_time_string():
    try:
        current_time = datetime.now()
        return current_time.strftime("%d%m%Y%H%M%S")
    except:
        return None


def get_start_timespan():
    try:
        current_time = datetime.now()
        expected_time = current_time - timedelta(minutes=current_time.minute)
        if expected_time.hour < 10:
            if expected_time.hour == 0:
                expected_start_time_text = expected_time.strftime("%b %d, %Y 12") + expected_time.strftime(
                    " %p")
            else:
                expected_start_time_text = expected_time.strftime("%b %d, %Y ") + str(
                    expected_time.hour) + expected_time.strftime(
                    " %p")
        else:
            expected_start_time_text = expected_time.strftime("%b %d, %Y %I %p")
        return expected_start_time_text
    except:
        return None


def get_random_dns():
    try:
        return random.sample(testdata.dns_https, 1)[0]
    except:
        return None


def get_random_bad_files_links():
    try:
        filename = random.sample(testdata.malicious_file, 1)[0]
        return filename, testdata.malicious_file[filename]
    except:
        return None, None



def get_random_int(start, end):
    try:
        return random.randint(start, end)
    except:
        return None


def set_initial_data():
    try:
        timespan = get_start_timespan()
        testdata.json_drive.__setitem__("time", {"start_time": timespan})
        memory_info = int(str(os.popen('grep MemTotal /proc/meminfo').read()).split(" ")[-2])
        memory_info = (float(memory_info) / 1024) / 1024
        memory_info = str(round(memory_info, 2))
        last_boot_time = str(os.popen('last reboot | head -1 | cut -b 43-55').read())
        last_boot_time = last_boot_time.replace(r"\n", "").strip()
        kernel_release = str(os.popen('uname -r').read())
        kernel_release = kernel_release.replace(r"\n", "").strip()
        default_router_ip = str(os.popen('ip route | grep default | cut -b 12-24').read())
        default_router_ip = default_router_ip.replace(r"\n", "").strip()
        private_ip = get_private_ip()
        private_ip = private_ip.replace(r"\n", "").strip()
        machine_name = get_hostname()
        machine_data = {
            "ip_address": private_ip,
            "machine_name": machine_name,
            "kernel_release": kernel_release,
            "last_boot_time": last_boot_time,
            "memory_info": memory_info,
            "default_router": default_router_ip
        }
        testdata.json_drive.__setitem__("initial_data", machine_data)
    except:
        return None

"""
def push_data_to_drive(json_drive_data, env=None):
    try:
        scope = ['https://spreadsheets.google.com/feeds']
        file_name = "/lacework.json"
        file_path = os.path.dirname(os.path.abspath(__file__))+file_name
        credentials = ServiceAccountCredentials.from_json_keyfile_name(file_path, scope)
        file_obj = gspread.authorize(credentials)
        sheet = file_obj.open("Lacework Data Driven Suite").JSON
        list_of_lists = sheet.get_all_values()
        next_cell = len(list_of_lists) + 1
        current_time = get_start_timespan()
        try:
            sheet.update_cell(next_cell, 1, json_drive_data["initial_data"]["machine_name"])
            sheet.update_cell(next_cell, 2, json_drive_data["initial_data"]["ip_address"])
        except:
            pass
        sheet.update_cell(next_cell, 3, env)
        sheet.update_cell(next_cell, 4, str(current_time))
        sheet.update_cell(next_cell, 5, str(json_drive_data))

        return True
    except:
        return None
"""

def create_tcp_port():
    try:
        tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        tcp.bind(('', 0))
        address, port = tcp.getsockname()
        time.sleep(2)
        tcp.close()
        time.sleep(2)
        httpd = SocketServer.TCPServer(('', port), None)
        httpd.server_activate()
        time.sleep(30)
        httpd.server_close()
        return port
    except:
        return None


def create_udp_port():
    try:
        udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        udp.bind(('', 0))
        address, port = udp.getsockname()
        time.sleep(2)
        udp.close()
        time.sleep(2)
        httpd = SocketServer.UDPServer(('', port), None)
        httpd.server_activate()
        time.sleep(30)
        httpd.server_close()
        return port
    except:
        return None


def send_http_get(url):
    try:
        http_request = requests.get(url)
        if http_request.status_code == 200:
            return True
        else:
            return False
    except:
        return False


def get_ip_from_dns(url):
    try:
        return socket.gethostbyname(url.split("//")[1])
    except:
        return None


def send_http_req_and_get_the_host_server_ip():
    try:
        url = random.sample(testdata.dns_ip_lookup, 1)[0]
        if send_http_get(url):
            ip_address = get_ip_from_dns(url)
            return url, ip_address
        return None
    except:
        return None


def read_config_json_parameters():
    try:
        with open(testdata.CONFIG_JSON_FILEPATH, "r") as config_file:
            json_data = json.load(config_file)
        json_data = eval(json.dumps(json_data))
        if json_data.has_key("fim"):
            filepath = json_data["fim"]["filepath"][0]
        else:
            filepath = None
        if json_data.has_key("tags"):
            tags = json_data["tags"]
        else:
            tags = None
        if json_data.has_key("serverurl"):
            env = str(str(json_data["serverurl"]).split("//")[1]).split(".")[0]
        else:
            env = None
        return {"filepath": filepath, "tags": tags, "environment": env}
    except Exception:
        return None


def utc_to_pst_date_converter(container_date):
    try:
        utc_date = datetime.strptime(container_date, "%Y-%m-%dT%H:%M:%S").replace(tzinfo=pytz.timezone("UTC"))
        converted_pst = utc_date.astimezone(pytz.timezone('America/Los_Angeles'))
        return converted_pst.strftime("%b %d, %Y %I:%M %p")
    except:
        return None


def get_container_details_from_container_json(file_path):
    created_time = None
    id = None
    image_name = None
    try:
        with open(file_path, "r") as config_file:
            json_data = json.load(config_file)
        created_time = utc_to_pst_date_converter(str(json_data[0]["Created"]).split(".")[0])
        id = str(json.dumps(json_data[0]["Id"]))
        image_name = str(json.dumps(json_data[0]["Config"]["Image"]))
        return {"Id": id, "image_name": image_name, "created_time": created_time}
    except:
        return {"Id": id, "image_name": image_name, "created_time": created_time}


def get_file_hash(modified_file_path):
    try:
        file_hash_command = "sha256sum " + modified_file_path + " | awk '{print $1}'"
        hash_name = str(os.popen(file_hash_command).read()).replace("\n", "")
        return hash_name
    except:
        return None


def modify_txt_file_n_get_details(folder_path):
    try:
        file_names_list = []
        for no_files in os.listdir(folder_path):
            if no_files.endswith(".txt"):
                file_names_list.append(no_files)
        modified_file_name = random.sample(file_names_list, 1)[0]
        modified_file_path = folder_path + "/" + modified_file_name
        old_hash = get_file_hash(modified_file_path)
        random_string_name = create_unique_date_and_time_string()
        subprocess.call(['echo thisismodifieddummy' + random_string_name + " >> " + modified_file_path ], shell=True)
        new_hash = get_file_hash(modified_file_path)
        return {"old_hash": old_hash, "new_hash": new_hash, "filename": modified_file_name, "file_path": modified_file_path}
    except:
        return {}


def create_txt_file_n_get_details(folder_path):
    try:
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
        random_string_name = create_unique_date_and_time_string()
        file_name = random_string_name + ".txt"
        file_path = folder_path + "/" + file_name
        subprocess.call(['echo thisisdummy' + random_string_name + " > " + file_path ], shell=True)
        new_hash = get_file_hash(file_path)
        modify_time = os.path.getmtime(file_path)
        modify_time = str(datetime.fromtimestamp(modify_time).strftime("%m/%d/%Y %I:%M %p"))
        return {"file_hash": new_hash, "filename": file_name, "file_path": file_path, "modified_time": modify_time}
    except:
        return {}


def get_file_size(file_path):
    try:
        file_size = os.path.getsize(file_path)
        for x in ['B','KB','MB','GB']:
            if file_size < 1024.0:
                return "%3.1f%s" % (file_size, x)
            file_size /= 1024.0
        return "%3.1f%s" % (file_size, 'TB')
    except:
        return None
