#! /bin/bash

if [ $# -eq 2 ]; then
    username=$1
    dns_name=$2
    su - $username -c "wget '$dns_name' -O /dev/null"
    if [ $? -eq 0 ]; then
        echo $username" - User did a Successful wget to "$dns_name
        exit 0
    else
        echo $username" - User Failed to do a wget to "$dns_name
        exit 1
    fi
fi
