import os
from datetime import datetime
import json
import subprocess
import testdata


def create_process():
    try:
        wget_date_and_time = str(os.popen('bash process.sh').read()).split("--")
        start_date_format = datetime.strptime(str(wget_date_and_time[0]), '%Y-%m-%d %H:%M:%S')
        start_date = start_date_format.date().strftime('%Y/%m/%d')+" "+start_date_format.time().strftime('%I:%M %p')
        end1=wget_date_and_time[1].replace("\n","").replace("(","").replace(" KB/s) -","").split(" ")[0]+" "+wget_date_and_time[1].replace("\n","").replace("(","").replace(" KB/s) -","").split(" ")[1]
        end_date_format = datetime.strptime(str(end1), '%Y-%m-%d %H:%M:%S')
        end_date = end_date_format.date().strftime('%Y/%m/%d')+" "+end_date_format.time().strftime('%I:%M %p')
        file_path= str(os.popen('which wget').read()).replace('\n', '')
        user_name = str(os.popen("echo $USER").read()).replace('\n', '')
        user_id = str(os.popen("id | grep -E -o '[0-9]+' | head -1").read()).replace('\n', '')
        data = {}
        data["Launch Time"]=start_date
        data["End Time"]=end_date
        data["File Path"]=file_path
        data["User Name"]=user_name
        data["Effective User ID"]=user_id
        json_data = json.dumps(data)
        testdata.json_drive.__setitem__("process", json_data)
    except:
        pass
    
    
def get_process_ids():
    try:
        get_pid_ppid = str(subprocess.check_output(['pidof','wget'])).split(" ")[0]
        formated_pid = get_pid_ppid.replace("\n", "")
        testdata.json_drive.__setitem__("process_id", json.dumps(formated_pid))
    except:
        pass




        
    

