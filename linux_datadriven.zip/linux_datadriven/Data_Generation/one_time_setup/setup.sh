#!/bin/bash

# Must be root to run this setup

PYTHON_PIP_PKG="python pip"
PYTHON_VERSION=2.7.10
INSTALL_PKGS="ssh sshpass wget curl"

command_exists() {
    command -v "$@" > /dev/null 2>&1
}

check_python_version(){
    if command_exists python; then
        var=$(python --version 2>&1 | grep -E -o "[0-9.]*")
        if [[ $var > $PYTHON_VERSION ]]; then
            echo "Compatible Python Version Found"
        else
            sudo apt-get install -y python
            echo -e "Updated python to $PYTHON_VERSION or greater\n"
        fi
    else
        sudo apt-get install -y python
        echo "Python Installed Success"
    fi
}

check_pip_installation(){
    if ! command_exists pip ; then
        echo "Pip is installing"
        sudo apt-get --assume-yes install python-pip
    fi
}

install_pip_dependancy(){
    cat requirements.txt | xargs -n 1 -L 1 pip install
}

install_pkg(){
    for pkg in $INSTALL_PKGS; do
      if ! command_exists $pkg ; then
          sudo apt-get install -y $pkg
          echo -e "$pkg package installed successfully"
      else
          echo -e "$pkg package already installed"
      fi
    done
}

change_file_permission(){
    # Give executable permission to all .sh script
    sudo chmod +x ./../*.sh
}

verify_automation_dependancy(){

	echo -e "Checking File Permission..."
	change_file_permission
	echo -e "File Permission Changed..."
	echo -e "Checking Python Version..."
	check_python_version
	echo -e "Checking PIP Version..."
	check_pip_installation
	echo -e "Checking PIP Package..."
	install_pip_dependancy
	install_pkg
	echo "Automation dependencies successfully installed"
}


do_install_and_run() {
	verify_automation_dependancy  
}


sudo apt-get update
pid=`sudo netstat -ap | grep :12345 | awk '{print $7}' | grep -E -o '[0-9]*'`
sudo kill -9 $pid
do_install_and_run
