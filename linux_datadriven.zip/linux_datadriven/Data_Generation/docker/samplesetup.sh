#! /bin/bash

apt-get update
apt-get install wget -y


URLLIST=( \
    "http://www.yahoo.com" \
    "http://www.gmail.com" \
    "http://www.w3schools.com" \
    "http://www.whatsapp.com" \
    "http://www.facebook.com" \
    "http://www.linkedin.com" \
    "http://www.instagram.com" \
)

URL=${URLLIST[ $(( RANDOM % ${#URLLIST[@]} )) ] }
wget --limit-rate=3k -O- $URL 2>&1 > /dev/null
echo "WGET TO "$URL

