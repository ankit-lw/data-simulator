cd /home
LWUSERS=`ls | grep -E -o "^ankit_user[0-9].*"`

#if [ -d "$LWUSERS" ]
#then
        #echo "$LWUSERS found."
        for user in $LWUSERS; do
               /usr/sbin/userdel --remove $user
        done
#else
#       echo "$LWUSERS No User found."
#fi
