#!/bin/bash

wget --limit-rate=2k -O- https://www.w3schools.com 2>&1 > /dev/null  | grep -E -o "[0-9].+[-]+"
