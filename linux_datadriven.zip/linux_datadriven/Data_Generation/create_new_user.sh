#!/bin/bash

SUCCESS=0

# Check if both arguments are Passed
if [ $# -eq 2 ]; then
    username=$1
    pass=$2

	# Check if user already exists.
	grep -q "$username" /etc/passwd
	if [ $? -eq $SUCCESS ]
	then
	    echo "User $username already exist, Could Not Create."
  	    exit 1
	fi

	# Command to Create New User
    /usr/sbin/adduser $username --gecos "" --disabled-password
    echo "$username:$pass" | sudo chpasswd

    # Verify User Created Successfully
    grep -q "$username" /etc/passwd
	if [ $? -eq $SUCCESS ]
	then
	    echo "User $username Created Successfully"
	    exit 0
	fi
else
        echo  "This program needs 2 arguments you have given $#"
        echo  "Please call the script $0 with username and password to be created"
        exit 1
fi
