#!/bin/bash

SUCCESS=0

# Verify all the 3 arguments are passed
if [ $# -eq 3 ]; then
    username=$1
    dns_name=$2
    count=$3
    for ((i=0;i<$count;i++)){
        (exec ./do_wget.sh $username $dns_name)
        sleep 5s
    }
fi
