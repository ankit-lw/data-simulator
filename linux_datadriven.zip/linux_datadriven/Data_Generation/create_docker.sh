#! /bin/bash

if [ $# -eq 3 ]; then
    docker_image_name=$1
    FILE_DIR=$2
    container_name=$3
    cd $FILE_DIR
    sleep 1s
    sudo docker build -t $docker_image_name . && sudo docker run --name=$container_name $docker_image_name
fi
