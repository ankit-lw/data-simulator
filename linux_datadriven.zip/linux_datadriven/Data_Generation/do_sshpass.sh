#!/bin/bash


USERNAME=$1
PASSWORD=$2
HOST=$3

command_exists()
{
    command -v "$@" > /dev/null 2>&1
}


THISMACHINENAME=`hostname`
THISMACHINENAME="sshpass_$THISMACHINENAME"

if ! command_exists $THISMACHINENAME; then
    sudo apt-get --assume-yes install sshpass
    sleep 3s
    sudo mv /usr/bin/sshpass /usr/bin/$THISMACHINENAME
    sleep 2s
fi

if command_exists $THISMACHINENAME; then
    NAME1=$(date +%Y%m%d%H%M%S)
    $THISMACHINENAME -p $PASSWORD ssh -o StrictHostKeyChecking=no $USERNAME@$HOST "mkdir LWA$NAME1" >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        exit 0
    else
        exit 1
    fi
else
    exit 1
fi




