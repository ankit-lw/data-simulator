#! /bin/bash


if [ $# -eq 1 ]; then
    container_name=$1
    container_id=`docker container ls -a | grep $container_name | awk '{print $1}'`
    docker inspect $container_id > container.json
    if [ $? -eq 0 ]; then
        echo $container_name" - Container created  successfully"
        exit 0
    else
        echo "Container Creation Failed"
        exit 1
    fi
fi
