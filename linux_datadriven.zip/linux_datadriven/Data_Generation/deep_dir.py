from datetime import datetime
import subprocess
import random

eicar_arr = [
    "https://secure.eicar.org/eicar.com",
    "https://secure.eicar.org/eicar.com.txt"
    "https://secure.eicar.org/eicar_com.zip"
    "https://secure.eicar.org/eicarcom2.zip"
]


def create_unique_date_and_time_string():
    try:
        current_time = datetime.now()
        return current_time.strftime("%d%m%Y%H%M%S")
    except:
        return None


def create_files_in_deep_dir():
    try:
        # Add your directory location here
        GLOBAL_FIM_LOCATION = "/FIM/Hidden_Folder/.ssh"
        for dir in range(0, 10):
            # --------- Create a unique folder path in /var/run/qa + unique date and time string
            DIR = "FIM_DIR_" + str(dir) + create_unique_date_and_time_string()
            DIR_FULL_PATH = GLOBAL_FIM_LOCATION + DIR
            # ------------- Below loop will create 10 unique folders
            for i in range(0, 10):
                FILE_NAME = DIR + "_DEEP_DIR_" + str(i)
                DEEP_DIR = DIR_FULL_PATH + "/" + FILE_NAME
                print("NEW LOC FOR DIR {} ".format(DEEP_DIR))
                subprocess.check_output(['mkdir', '-p', DEEP_DIR])
                # ============ Create New Files
                for i in range(0, 10):
                    FILE_LOC = DEEP_DIR + "/" + DIR + "_TEST_FILE_" + str(i) + ".txt"
                    subprocess.check_output(['touch', FILE_LOC])
                    print("Created FILE in {} Location".format(FILE_LOC))
                    wget_url = random.sample(eicar_arr, 1)[0]
                    subprocess.check_output(['wget', '-P', DEEP_DIR, wget_url])

            print("**" * 50)

    except Exception as ex:
        print(ex)


create_files_in_deep_dir()
