import os
import time
import subprocess
import testdata
import data_fixtures
import logging
from threading import Thread
from get_process_details import create_process, get_process_ids
import requests
import random

LOG_FILENAME = "data_driven_log.log"
FORMAT = '%(asctime)s - %(levelname)s - %(message)s'
logging.basicConfig(level=logging.INFO, format=FORMAT, datefmt='%d/%m/%Y %H:%M:%S', filename=LOG_FILENAME, filemode='w')


def generate_data():
    try:
        config_json_data = data_fixtures.read_config_json_parameters()

        # ---- Gather Initial Data

        data_fixtures.set_initial_data()
        logging.info("Gathered initial data - " + str(testdata.json_drive))

        # ----- Modify Any Existing txt File

        new_file_folder = config_json_data["filepath"] + "/NF"
        if os.path.exists(new_file_folder):
            modified_file_data = data_fixtures.modify_txt_file_n_get_details(new_file_folder)
            if len(modified_file_data) > 0:
                testdata.json_drive.__setitem__("modified_file", modified_file_data)
                logging.info("Modified a txt file - " + str(modified_file_data))
            else:
                logging.error("Failed to modify any existing txt file")
        else:
            logging.error("Failed to modify any existing txt file")

        # ----- Create New txt File

        new_file_data = data_fixtures.create_txt_file_n_get_details(new_file_folder)
        if len(new_file_data) > 0:
            testdata.json_drive.__setitem__("new_file", new_file_data)
            logging.info("New txt file created - " + str(new_file_data))
        else:
            logging.error("Failed to create a new txt file")

        # ----- Creating user

        # dns_web = data_fixtures.get_random_dns()
        dns_web = "http://ipv4.download.thinkbroadband.com/100MB.zip"
        username = data_fixtures.create_unique_username()
        no_of_wget = data_fixtures.get_random_int(1, 5)
        return_value = subprocess.call(
            ['bash ' + testdata.DIR_NAME + '/create_new_user.sh ' + username + " " + testdata.dummy_password],
            shell=True)
        if return_value == 0:
            logging.info("Created new user - " + username)
        else:
            logging.error("Failed to Create a new user ")
        time.sleep(2)

        # ----- Created user does a wget for n times

        subprocess.call([
            'bash ' + testdata.DIR_NAME + '/do_wget_n_times.sh ' + username + " " + dns_web + " " + str(
                1)],
            shell=True)
        logging.info(username + " did wget to " + dns_web + " " + str(1) + " times.")
        time.sleep(5)

        user_id = str(subprocess.check_output(["id", "-u", username])).replace(r"\n", "").strip()

        created_user_data = {
            "name": username,
            "uid": user_id,
            "wget_repetitive": {"dns": dns_web, "count": str(no_of_wget)}}
        testdata.json_drive.__setitem__("created_user", created_user_data)

        # ----- Download Malicious Files Non Executable

        malicious_file_name, malicious_file_link = data_fixtures.get_random_bad_files_links()
        bad_file_folder = config_json_data["filepath"] + "/BFNE/" + data_fixtures.create_unique_date_and_time_string()
        return_value = subprocess.call(
            ['bash ' + testdata.DIR_NAME + '/download_bad_file.sh ' + malicious_file_link + " " + bad_file_folder],
            shell=True)
        if return_value == 0:
            logging.info("Downloaded Malicious File: " + malicious_file_name + " in Folder - " + bad_file_folder)
        else:
            logging.error(
                "Failed to Download Malicious File: " + malicious_file_name + " in Folder - " + bad_file_folder)
        time.sleep(1)
        malicious_file_data = {
            "File Owner": "root",
            "File Path": bad_file_folder,
            "File Name": malicious_file_name
        }
        testdata.json_drive.__setitem__("non_executabe_bad_files", malicious_file_data)

        # ----- Download Malicious Files Executable

        malicious_file_name, malicious_file_link = data_fixtures.get_random_bad_files_links()
        bad_file_folder = config_json_data["filepath"] + "/BFE/" + data_fixtures.create_unique_date_and_time_string()
        return_value = subprocess.call([
            'bash ' + testdata.DIR_NAME + '/download_executable_bad_file.sh ' + malicious_file_link + " " + bad_file_folder],
            shell=True)
        if return_value == 0:
            logging.info(
                "Downloaded Executable Malicious File: " + malicious_file_name + " in Folder - " + bad_file_folder)
        else:
            logging.error(
                "Failed to Download Executable Malicious File: " + malicious_file_name + " in Folder - " + bad_file_folder)
        time.sleep(1)
        malicious_file_data = {
            "File Owner": "root",
            "File Path": bad_file_folder,
            "File Name": malicious_file_name
        }
        testdata.json_drive.__setitem__("executabe_bad_files", malicious_file_data)

        # ----- Create TCP Port

        tcp_port_no = str(data_fixtures.create_tcp_port())
        tcp_port_data = {"port_number": tcp_port_no, "application": "python"}
        testdata.json_drive.__setitem__("tcp_port", tcp_port_data)
        if tcp_port_no is not None:
            logging.info("Created TCP Port - " + tcp_port_no)
        else:
            logging.error("Failed to Create TCP Port.")

        # ----- Create UDP Port

        udp_port_no = str(data_fixtures.create_udp_port())
        udp_port_data = {"port_number": udp_port_no, "application": "python"}
        testdata.json_drive.__setitem__("udp_port", udp_port_data)
        if udp_port_no is not None:
            logging.info("Created UDP Port - " + udp_port_no)
        else:
            logging.error("Failed to Create UDP Port.")

        # ----- Do sshpass From Agent

        return_value = subprocess.call([
            'bash ' + testdata.DIR_NAME + '/do_sshpass.sh ' + testdata.ssh_other_username + " " + testdata.ssh_other_password + " " + testdata.ssh_other_ip],
            shell=True)
        if return_value == 0:
            logging.info(
                "SSH done successfully to username - " + testdata.ssh_other_username + "@" + testdata.ssh_other_ip)
        else:
            logging.error(
                "SSH failed to connect to username - " + testdata.ssh_other_username + "@" + testdata.ssh_other_ip)
        time.sleep(1)
        testdata.json_drive.__setitem__("application", "sshpass")

        # ----- Do Failed DNS LookUp

        failed_url = testdata.FAILED_DNS + username + ".com"
        if data_fixtures.send_http_get(failed_url):
            logging.error("Got Response When Sent HTTP Request to " + failed_url)
        else:
            logging.info("Sent Expected Failed HTTP Request to " + failed_url)
        testdata.json_drive.__setitem__("non_exist_url", failed_url)

        # ----- Create Docker

        date_time_string = data_fixtures.create_unique_date_and_time_string()
        image_name = "img" + date_time_string
        container_name = "contr" + date_time_string
        docker_file_dir = testdata.DIR_NAME + "/docker"
        subprocess.call([
            'bash ' + testdata.DIR_NAME + '/create_docker.sh ' + image_name + " " + docker_file_dir + " " + container_name],
            shell=True)
        return_value = subprocess.call(['bash ' + testdata.DIR_NAME + '/create_container_json.sh ' + container_name],
                                       shell=True)
        if return_value == 0:
            logging.info(container_name + " named container created with Image - " + image_name)
            container_details = data_fixtures.get_container_details_from_container_json(
                testdata.DIR_NAME + "/container.json")
            testdata.json_drive.__setitem__("container", container_details)
        else:
            logging.error("Failed to create any container")

        # ----- Process Dossier

        process = Thread(target=create_process)
        process.start()
        time.sleep(1)
        process_id = Thread(target=get_process_ids)
        process_id.start()
        while process.isAlive():
            time.sleep(5)

        # ----- Request a valid Login SSH to this system

        valid_count = str(random.randint(1, 2))
        request_login_url = "http://" + testdata.ssh_other_ip + ":" + testdata.ssh_other_port + "/?login_script?username=" + testdata.host_username + "?count=" + valid_count + "?host=" + testdata.host_ip.replace(
            ".", "-")
        http_request = requests.get(request_login_url)
        if http_request.status_code == 200:
            logging.info(
                "SSH was done to IP - " + testdata.host_ip + " From IP - " + testdata.ssh_other_ip + " With username - " + testdata.host_username)
            testdata.json_drive.__setitem__("remote_valid_login",
                                            {"From": testdata.ssh_other_ip, "To": testdata.host_ip,
                                             "username": testdata.host_username, "count": valid_count})
        else:
            logging.error("Failed to do an SSH Login to this system from other")

        time.sleep(20)

        # ----- Request an invalid Login SSH to this system

        invalid_count = str(random.randint(1, 3))
        username_date_time_string = "ssh" + data_fixtures.create_unique_date_and_time_string()
        request_login_url = "http://" + testdata.ssh_other_ip + ":" + testdata.ssh_other_port + "/?login_script?username=" + username_date_time_string + "?count=" + valid_count + "?host=" + testdata.host_ip.replace(
            ".", "-")
        http_request = requests.get(request_login_url)
        if http_request.status_code == 200:
            logging.info(
                "SSH was done to IP - " + testdata.host_ip + " From IP - " + testdata.ssh_other_ip + " With invalid username - " + username_date_time_string)
            testdata.json_drive.__setitem__("remote_invalid_login",
                                            {"From": testdata.ssh_other_ip, "To": testdata.host_ip,
                                             "username": username_date_time_string, "count": invalid_count})
        else:
            logging.error("Failed to do an SSH Login to this system from other")

        time.sleep(7)
    except:
        pass


def clean_up_automated_data():
    # --- del user from host
    return_value = subprocess.call([
        'bash ' + testdata.DIR_NAME + '/deluser.sh '], shell=True)
    if return_value == 0:
        logging.info("deleted all user starting with 'ankit' ")
    else:
        logging.error("failed to delete user starting with 'ankit'")

    # --- del container from host
    return_value = subprocess.call([
        'bash ' + testdata.DIR_NAME + '/del_docker.sh '], shell=True)
    if return_value == 0:
        logging.info("deleted all container from host ")
    else:
        logging.error("failed to remove all container from host")


if __name__ == '__main__':
    generate_data()
    time.sleep(300)
    clean_up_automated_data()
