
crontab -l > set_cron #echo new cron into cron file


echo "0 * * * * cd /home/$USER/Music/data_generation && /usr/bin/python /home/$USER/Music/data_generation/run.py">>set_cron
echo "">>set_cron


 #install new cron file

crontab set_cron

#rm set_cron




