import os

dns_ip_lookup = ['https://www.github.com', 'https://www.stackexchange.com', 'https://www.learnpython.org',
                 'https://www.codecademy.com', 'https://www.codeschool.com', 'https://www.vodafone.in',
                 'https://www.airtel.in', 'https://www.ideacellular.com']

dns_https = ['https://www.programiz.com', 'https://www.linkedin.com', 'https://www.nm.org',
             'https://www.hopkinsmedicine.org', 'https://www.tmall.com', 'https://www.whois.net',
             'https://www.saintfrancis.com', 'https://www.tumblr.com', 'https://www.w3schools.in',
             'https://www.whatsapp.com', 'https://www.guru99.com', 'https://www.codecademy.com',
             'https://www.bswhealth.com', 'https://www.chesapeakeregional.com', 'https://www.github.com',
             'https://www.luriechildrens.org', 'https://www.mskcc.org', 'https://www.studytonight.com',
             'https://www.netflix.com', 'https://www.javatpoint.com', 'https://www.instagram.com',
             'https://www.wix.com', 'https://twitter.com/', 'https://www.chla.org', 'https://www.wordpress.com',
             'https://www.indiabix.com', 'https://www.mayoclinic.org', 'http://www.name.com', 'https://www.ebay.com',
             'https://www.avito.ru/', 'https://www.tutorialspoint.com', 'https://www.rush.edu']

malicious_file = {"eicar.com": "https://secure.eicar.org/eicar.com",
                  "eicar.com.txt": "https://secure.eicar.org/eicar.com.txt",
                  "eicarcom2.zip": "https://secure.eicar.org/eicarcom2.zip",
                  "eicar_com.zip": "https://secure.eicar.org/eicar_com.zip"}


# ----- Test Data used for SSH to other system that has no agent installed.

ssh_other_ip = "192.168.1.179"
ssh_other_username = "dummy179"
ssh_other_password = "dummy123"
ssh_other_port = "12347"

# ----- This host Test Data on which Agent is Installed

host_username = "dummy14"
host_password = "dummy123"
host_ip = "192.168.1.14"
ssh_this_port = "12345"

# ----- Dummy Data

dummy_password = "dummy123"
dns_common = "http://www.yahoo.com"

# ----- Constants

CONFIG_JSON_FILEPATH = "/var/lib/lacework/config/config.json"
DIR_NAME = os.path.dirname(os.path.realpath(__file__))
FAILED_DNS = "http://www.thescbankcominthe"
docker_base_image = "FROM ubuntu:15.04"

# ----- Json Template

json_drive_format = {
    "time": {
        "start_time": "Nov 13, 12 AM"
    },
    "machine": {
        "ip_address": "192.168.1.14",
        "machine_name": "dummy-vm",
        "kernel_release": "3.16.0-30-generic",
        "last_boot_time": "11/20/2017 2:21 AM",
        "memory_info": "3.08GB",
        "default_router": "192.168.1.1"
    },
    "created_user": {
        "name": "lw13111210",
        "wget_repetitive": {"dns": "https://www.guru99.com", "count": "4"},
    }, "port": {"port_number": "8888", "application": "python"},
    "application": [{"application": "sshpass", "username": "dummyuser", "hostname": "dummyuser-vm"},
                    {"application": "curl", "username": "dummyuser", "hostname": "dummyuser-vm"}],
    "existing_user": {
        "name": "dummyuser",
        "dns_failed": ["http://www.dummyautomationbyqaindia.com", "http://www.dummyautomationbyqaindia1.com"],
    }
}

json_drive = {}
