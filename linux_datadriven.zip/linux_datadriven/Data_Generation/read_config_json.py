import json
import testdata


def read_config_json_parameters():
    try:
        with open(testdata.CONFIG_JSON_FILEPATH, "r") as config_file:
            json_data = json.load(config_file)
        json_data = eval(json.dumps(json_data))
        if json_data.has_key("fim"):
            filepath = json_data["fim"]["filepath"][0]
        else:
            filepath = None
        if json_data.has_key("tags"):
            tags = json_data["tags"]
        else:
            tags = None
        if json_data.has_key("serverurl"):
            env = str(str(json_data["serverurl"]).split("//")[1]).split(".")[0]
        else:
            env = None
        return {"filepath": filepath, "tags": tags, "environment": env}
    except Exception:
        return None



